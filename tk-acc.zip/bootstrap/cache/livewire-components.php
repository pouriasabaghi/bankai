<?php return array (
  'customer-and-company' => 'App\\Http\\Livewire\\CustomerAndCompany',
  'select-or-create-service' => 'App\\Http\\Livewire\\SelectOrCreateService',
);