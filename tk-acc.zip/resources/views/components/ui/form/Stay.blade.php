<x-ui.form.InputCheckbox name='stay_in_page' label='ماندن در صفحه' value='true' />
