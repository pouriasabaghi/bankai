<thead>
    {{ $slot }}
</thead>
