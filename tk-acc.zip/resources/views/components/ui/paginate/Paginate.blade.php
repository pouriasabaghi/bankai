<div class="{{ $class ?? '' }}">
    {{ $paginate->links('pagination') }}
</div>
