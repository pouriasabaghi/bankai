<div class="loader" {{ $livewire ?? '' }}>
    <div   class="spinner-{{ $type ?? 'border' }}
                  spinner-{{ $type ?? 'border' }}-sm text-{{ $color ?? 'primary' }}
                  {{ $class ?? '' }}">
    </div>
</div>
