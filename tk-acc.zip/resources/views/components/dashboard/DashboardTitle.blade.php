<h1 class="h3 mb-3">
  {{ $slot }}
</h1>
