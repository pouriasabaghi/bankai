<ul class="sidebar-nav">
    {{ $slot }}
</ul>
