import './dashboard/index.js';
import './plugins/plugins.js';
import './helpers/helpers.js';
import './installments/installments.js'
import './receives/receives.js'



function license() {
    var textArt = "  ____          _   _ _  __         _____ \n" +
                  " |  _ \\   /\\   | \\ | | |/ /   /\\   |_   _|\n" +
                  " | |_) | /  \\  |  \\| | ' /   /  \\    | |  \n" +
                  " |  _ < / /\\ \\ | . ` |  <   / /\\ \\   | |  \n" +
                  " | |_) / ____ \\| |\\  | . \\ / ____ \\ _| |_ \n" +
                  " |____/_/    \\_|_| \\_|_|\\_/_/    \\_|_____|\n" +
                  "                                           \n";

    console.log(textArt);
}

//license();
