<thead>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/UI/table/Thead.blade.php ENDPATH**/ ?>