<div class="col-md-<?php echo e($col ?? '12'); ?> mb-3">
    <div class="form-group">
        <?php if(!empty($label)): ?>
            <label class='form-label' for="<?php echo e(!empty($id) ? $id : $name); ?>"><?php echo e($label); ?></label>
        <?php endif; ?>
        <input
            <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo e($key . '=' . $attribute); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
            name="<?php echo e(!empty($name) ? $name : ''); ?>"
            type="<?php echo e(!empty($type) ? $type : 'text'); ?>"
            class="form-control mt-1 text-start <?php echo e(!empty($class) ? $class : ''); ?>"
            placeholder="<?php echo e(!empty($placeholder) ? $placeholder : ''); ?>" autocomplete="off"
            value="<?php echo e(!empty($value) ? $value : ''); ?>" style="<?php echo e($style ?? ''); ?>" <?php echo e($livewire ?? ''); ?>

            >
    </div>

    <?php if(!empty($datalist)): ?>
        <?php echo e($datalist); ?>

    <?php endif; ?>
</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/Input.blade.php ENDPATH**/ ?>