<li class="sidebar-item <?php echo e(!empty($active) ? 'active' : ''); ?>">
    <a data-bs-target="#<?php echo e($id); ?>" data-bs-toggle="collapse" class="sidebar-link collapsed" aria-expanded="false">
        <span data-feather="<?php echo e($icon ?? 'circle'); ?>"></span>
        <span class="align-middle"><?php echo e($title); ?></span>
    </a>

    <ul id="<?php echo e($id); ?>" class="sidebar-dropdown list-unstyled collapse <?php echo e(!empty($active) ? 'show' : ''); ?>"
        data-bs-parent="#sidebar">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="sidebar-item <?php echo e(is_route_active(false, $route) ? 'active' : ''); ?>">
                <a class="sidebar-link" href="<?php echo e(route($route) ?? '#'); ?>"><?php echo e($title); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(!empty($title1)): ?>
            <li class="sidebar-item">
                <a data-bs-target="#<?php echo e($id); ?>-2" data-bs-toggle="collapse" class="sidebar-link collapsed"
                    aria-expanded="false"><?php echo e($title1); ?></a>
                <ul id="<?php echo e($id); ?>-2" class="sidebar-dropdown list-unstyled collapse">
                    <?php $__currentLoopData = $items2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="sidebar-item <?php echo e(is_route_active(false, $route) ? 'active' : ''); ?>">
                            <a class="sidebar-link" href="<?php echo e(route($route) ?? '#'); ?>"><?php echo e($title); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!empty($title2)): ?>
                        <li class="sidebar-item">
                            <a data-bs-target="#<?php echo e($id); ?>-3" data-bs-toggle="collapse"
                                class="sidebar-link collapsed" aria-expanded="false"><?php echo e($title2); ?></a>
                            <ul id="<?php echo e($id); ?>-3" class="sidebar-dropdown list-unstyled collapse">
                                <?php $__currentLoopData = $items3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title => $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="sidebar-item <?php echo e(is_route_active($route) ? 'active' : ''); ?>">
                                        <a class="sidebar-link"
                                            href="<?php echo e(route($route) ?? '#'); ?>"><?php echo e($title); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
</li>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/dashboard/SidebarItemMulti.blade.php ENDPATH**/ ?>