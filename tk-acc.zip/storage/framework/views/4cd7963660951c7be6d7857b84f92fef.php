<thead>
    <?php echo e($slot); ?>

</thead>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/table/Thead.blade.php ENDPATH**/ ?>