<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir='rtl'>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="حسابداری">
    <title>وب اپلیکیشن</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/admin/app.css']); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body dir='rtl' data-sidebar-position="right">


    <div class="wrapper">
        <?php echo $__env->make('admin.layouts.template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main">
            <?php echo $__env->make('admin.layouts.template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="content">
                <div class="container-fluid p-0">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </main>

            <?php echo $__env->make('admin.layouts.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('assets/plugins/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/persian-datepicker.js')); ?>"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/admin/app.js']); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            $(".advance-select").select2({
                placeholder: 'انتخاب کنید',
                language: {
                    noResults: function() {
                        return "موردی یافت نشد";
                    }
                }
            });
        })
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/admin/master.blade.php ENDPATH**/ ?>