<div class="form-check">
    <?php if(!empty($label)): ?>
    <label class="form-check-label mb-3" for="<?php echo e($id ?? ($name ?? '')); ?>">
        <?php echo e($label); ?>

    </label>
<?php endif; ?>


    <input
        <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php echo e($key . '=' . $attribute); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
        name="<?php echo e(!empty($name) ? $name : ''); ?>"
        type="<?php echo e(!empty($type) ? $type : 'checkbox'); ?>"
        class=" <?php echo e(!empty($class) ? $class : ''); ?>"
        value="<?php echo e(!empty($value) ? $value : ''); ?>" style="<?php echo e($style ?? ''); ?>"
        id="<?php echo e($id ?? ($name ?? '')); ?>"
        <?php echo e(!empty($checked) && $checked == true ? 'checked' : ''); ?>

        >


</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/InputCheckbox.blade.php ENDPATH**/ ?>