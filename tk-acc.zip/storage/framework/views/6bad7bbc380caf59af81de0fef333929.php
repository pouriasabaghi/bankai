<div class="col-md-<?php echo e($col ?? '12'); ?> mb-3">
    <div class="form-group">
        <?php if(!empty($label)): ?>
            <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
        <?php endif; ?>
        <input
            <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo e($key . '=' . $attribute); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
            id="<?php echo e($name); ?>" class="mt-1  form-control" value="<?php echo e($value); ?>" name="<?php echo e($name); ?>"
            readonly
            placeholder="<?php echo e($placeholder ?? ''); ?>"
            />
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', ()=>{
        $('input[name="<?php echo e($name); ?>"]').persianDatepicker({
            cellWidth: 32,
            cellHeight: 30,
            fontSize: 16,
            formatDate: "YYYY/0M/0D",

        })
    })
</script>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/Datepicker.blade.php ENDPATH**/ ?>