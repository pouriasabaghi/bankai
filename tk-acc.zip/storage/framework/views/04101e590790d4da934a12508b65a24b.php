<div class="card"
<?php if(!empty($id)): ?>
    id="<?php echo e($id); ?>"
<?php endif; ?>
>
    <?php if(!empty($header)): ?>
        <div class="card-header">
            <h5 class="card-title "><?php echo e($header); ?></h5>
            <?php if(!empty($subtitle)): ?>
                <h6 class="card-subtitle text-muted"><?php echo e($subtitle); ?></h6>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if(!empty($body)): ?>
        <div class="card-body">
            <?php echo e($body); ?>

        </div>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/card/Card.blade.php ENDPATH**/ ?>