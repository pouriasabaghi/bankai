
<form method="<?php echo e(empty($method) || $method == 'get' ? 'get' : 'post'); ?>" action="<?php echo e($action ?? ''); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field($method ?? 'get'); ?>
    <?php echo e($slot); ?>

</form>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/Form.blade.php ENDPATH**/ ?>