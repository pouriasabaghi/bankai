<option <?php echo e(!empty($disabled) ? 'disabled' : ''); ?> <?php echo e(!empty($selected) ? 'selected' : ''); ?> class="<?php echo e($class ?? ''); ?>"
    value="<?php echo e($value ?? ''); ?>" data-value="<?php echo e($value ?? 0); ?>">
    <?php echo e($slot); ?>

</option>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/Option.blade.php ENDPATH**/ ?>