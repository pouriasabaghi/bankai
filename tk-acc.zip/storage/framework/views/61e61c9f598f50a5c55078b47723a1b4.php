<a class="sidebar-brand" href="index.html">
    <span class="align-middle">نرم‌افزار حسابداری
        <span class="text-danger">بانکای</span>
    </span>
</a>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/dashboard/SidebarTitle.blade.php ENDPATH**/ ?>