<h1 class="h3 mb-3">
  <?php echo e($slot); ?>

</h1>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/dashboard/DashboardTitle.blade.php ENDPATH**/ ?>