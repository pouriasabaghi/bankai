<div class="alert alert-<?php echo e($alert ?? 'danger'); ?> <?php echo e(!empty($outline) ? 'alert-outline-coloured ' : ''); ?>" >
    <div class="alert-icon">
        <i class="far fa-fw fa-<?php echo e($icon ?? 'bell'); ?>"></i>
    </div>
    <div class="alert-message">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/alert/Alert.blade.php ENDPATH**/ ?>