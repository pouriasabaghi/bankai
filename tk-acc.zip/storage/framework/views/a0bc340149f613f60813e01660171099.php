<tbody>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/table/Tbody.blade.php ENDPATH**/ ?>