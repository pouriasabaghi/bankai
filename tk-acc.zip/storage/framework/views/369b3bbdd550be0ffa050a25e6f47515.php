<div class="row">
    <?php if(isset($exception)): ?>
        <div class="alert alert-danger">
            <?php echo e($exception->getMessage()); ?>

        </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
        <div class="col-12">
            <div class="alert alert-danger">
                <ul class='mb-0 mx-4'>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="my-2"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/InputLayout.blade.php ENDPATH**/ ?>