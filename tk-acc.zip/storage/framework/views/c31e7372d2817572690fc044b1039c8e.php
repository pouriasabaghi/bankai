<div class="loader" <?php echo e($livewire ?? ''); ?>>
    <div   class="spinner-<?php echo e($type ?? 'border'); ?>

                  spinner-<?php echo e($type ?? 'border'); ?>-sm text-<?php echo e($color ?? 'primary'); ?>

                  <?php echo e($class ?? ''); ?>">
    </div>
</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/loader/Loader.blade.php ENDPATH**/ ?>