<ul class="sidebar-nav">
    <?php echo e($slot); ?>

</ul>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/dashboard/SidebarNav.blade.php ENDPATH**/ ?>