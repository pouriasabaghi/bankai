<?php if(!empty($href)): ?>
    <a
        <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo e($key . '=' . $attribute); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>

        href="<?php echo e($href); ?>" class="btn  btn-<?php echo e($btn ?? 'primary'); ?> text-white rounded <?php echo e($class ?? ''); ?>">
        <span><?php echo e($slot); ?></span>
    </a>
<?php else: ?>
    <button <?php echo e(!empty($disabled) && $disabled == true ? 'disabled' : ''); ?> type="<?php echo e($type ?? 'submit'); ?>"
        <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo e($key . '=' . $attribute); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
        class="btn  btn-<?php echo e($btn ?? 'primary'); ?> text-white rounded <?php echo e($class ?? ''); ?>" <?php echo e($livewire ?? ''); ?>>
        <span><?php echo e($slot); ?></span>
    </button>
<?php endif; ?>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/button/Button.blade.php ENDPATH**/ ?>