<div class="<?php echo e($class ?? ''); ?>">
    <?php echo e($paginate->links('pagination')); ?>

</div>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/paginate/Paginate.blade.php ENDPATH**/ ?>