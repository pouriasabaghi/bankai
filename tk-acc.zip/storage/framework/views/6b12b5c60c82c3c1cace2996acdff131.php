

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.Form','data' => ['method' => ''.e($formAttributes['method']).'','action' => ''.e($formAttributes['action']).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.Form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['method' => ''.e($formAttributes['method']).'','action' => ''.e($formAttributes['action']).'']); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.form.InputLayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.form.InputLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="col-12">
            <div class="row manage-row__group">
                <?php $__currentLoopData = $receives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 manage-row__items <?php echo e($loop->index == 0 ? '' : 'mt-3'); ?>

                        <?php echo e($loop->index == 0 || !empty($receive->created_at) ? '' : 'd-none'); ?>"
                        data-row-count="<?php echo e($loop->index + 1); ?>">
                        <div class="d-flex align-items-center mb-2">
                            <i role='button'
                                class="fa-solid fa-circle-xmark fa-lg align-items-center d-flex fa-solid  me-2
                                <?php echo e($loop->index == 0 ? 'text-secondary' : 'text-danger manage-row__button_delete'); ?>">
                            </i>
                            <h6 class="mb-0">دریافتی شماره <?php echo e($loop->index + 1); ?></h6>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <div class="row">
                                    <?php echo $__env->make('admin.receives.layouts.default-inputs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <hr />
                            </div>
                            <div class="col-12">
                                <a class="nav-link dropdown-toggle toggle-type-container" href="#"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="h6 mb-2 d-inline-block">اطلاعات
                                        
                                        <span class="type-label">چک</span>
                                    </span>
                                </a>
                                <div class="dropdown-menu text-start">
                                    <span role="button" class="dropdown-item inside-toggle-type-buttons"
                                        data-toggle-type='deposit'>واریز</span>
                                    <span role="button" class="dropdown-item inside-toggle-type-buttons"
                                        data-toggle-type='check'>چک</span>
                                </div>
                            </div>
                            <div class="col-12 <?php echo e(($loop->index == 0 && ((!empty($receive->type) && $receive->type != 'deposit') || empty($receive->type))) ||
                            (!empty($receive->type) && $receive->type == 'check') ? ''  : 'd-none'); ?>"
                                data-type='check'>
                                <div class="row">
                                    <?php echo $__env->make('admin.receives.layouts.check-inputs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                            <div class="col-12 <?php echo e(!empty($receive->type) && $receive->type == 'deposit' ? '' : 'd-none'); ?>"
                                data-type='deposit'>
                                <div class="row">
                                    <?php echo $__env->make('admin.receives.layouts.deposit-inputs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 text-end mt-3">
                    <div class="btn-group add-receive-toggle-type-container">
                        <div class="btn-group " role="group">
                            <button type="button" class="btn btn-outline-success dropdown-toggle"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="type-label">چک</span>
                            </button>
                            <div class="dropdown-menu text-start ">
                                <span role="button" class="dropdown-item toggle-type-buttons"
                                    data-toggle-type='deposit'>واریز</span>
                                <span role="button" class="dropdown-item toggle-type-buttons"
                                    data-toggle-type='check'>چک</span>
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button.Button','data' => ['type' => 'button','class' => 'btn-sm manage-row__button no-rounded','btn' => 'success','attr' => ['data-type' => 'check']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.button.Button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'btn-sm manage-row__button no-rounded','btn' => 'success','attr' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['data-type' => 'check'])]); ?>
                            افزودن
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">

            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button.Button','data' => ['class' => 'submit-form']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ui.button.Button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'submit-form']); ?>
                ذخیره
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/admin/receives/layouts/form.blade.php ENDPATH**/ ?>