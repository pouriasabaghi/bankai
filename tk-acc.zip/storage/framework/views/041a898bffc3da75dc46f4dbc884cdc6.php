<tbody>
    <?php echo e($slot); ?>

</tbody>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/UI/table/Tbody.blade.php ENDPATH**/ ?>