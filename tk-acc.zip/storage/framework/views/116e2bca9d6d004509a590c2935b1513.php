<?php if(!empty($label)): ?>
<li class="sidebar-header">
    <?php echo e($label); ?>

</li>

<?php endif; ?>
<li class="sidebar-item <?php echo e(!empty($active) ? 'active' : ( !empty($route) && is_route_active($route) ? 'active' : '' )); ?>">
    <a class="sidebar-link" href="<?php echo e(!empty($href) ? $href : (!empty($route)  ? route($route)   : '#' )); ?>">
        <i class="align-middle" data-feather="<?php echo e($icon ?? ''); ?>"></i>
        <span class="align-middle"><?php echo e($title); ?></span>
    </a>
</li>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/dashboard/SidebarItem.blade.php ENDPATH**/ ?>