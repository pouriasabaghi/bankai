<div class="col-md-<?php echo e($col ?? '12'); ?> mb-3">
    <div class="form-group">
        <?php if(!empty($label)): ?>
            <label class='form-label d-block'><?php echo e($label); ?></label>
        <?php endif; ?>
        <select <?php echo e(!empty( $multiple) ? "multiple=multiple" : ''); ?> <?php echo e($livewire ?? ''); ?> name="<?php echo e($name ?? ''); ?>"
            class="<?php echo e(empty($script) ? 'advance-select' : ''); ?> <?php echo e($class ?? ''); ?>">
            <?php echo e($slot); ?>

        </select>
    </div>
</div>

<?php if(!empty($script)): ?>
    <?php if($script != 'no'): ?>
        <?php echo e($script); ?>

    <?php endif; ?>
<?php endif; ?>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/form/Select.blade.php ENDPATH**/ ?>