<a <?php $__empty_1 = true; $__currentLoopData = $attributes = !empty($attr) ? $attr : []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo e($key . '=' . $attribute); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <?php endif; ?>
    href="<?php echo e($href ?? ''); ?>" class="<?php echo e($class ?? ''); ?>">

<?php echo e($slot); ?>


</a>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/button/Link.blade.php ENDPATH**/ ?>