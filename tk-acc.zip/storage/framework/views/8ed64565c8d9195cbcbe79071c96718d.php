<span data-feather='trash'></span>
<?php /**PATH E:\laragon\www\tk-acc\resources\views/components/ui/icon/Delete.blade.php ENDPATH**/ ?>